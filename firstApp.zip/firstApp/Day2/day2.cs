﻿using System;

namespace Day2
{
    class Program
    {
        static void Main(string[] args)
        {

            // if statement
            Console.WriteLine("Enter number: ");
            int number = Convert.ToInt32(Console.ReadLine());
            if (number % 2 == 0)
            {
                Console.WriteLine("{0} is even", number);

            }
            else
            {
                Console.WriteLine("{0} is odd", number);

            }

            //if statment
            Console.WriteLine("Plaese Enter the Number : ");
            int num = Convert.ToInt32(Console.ReadLine());
            if (num % 2 == 0)
            {
                Console.WriteLine(" {0} is enevn number", num);
            }
            else
            {
                Console.WriteLine("{0} is odd Number", num);
            }


            //if statment
            Console.WriteLine("Plaese Enter the Grade : ");
            int Number = Convert.ToInt32(Console.ReadLine());
            if (Number < 0 || Number > 100)
            {
                Console.WriteLine("  Wrong number");
            }
            else if (Number >= 0 && Number < 50)
            {
                Console.WriteLine("  Fail");
            }
            else if (Number >= 50 && Number < 60)
            {
                Console.WriteLine("  Pass");
            }
            else if (Number >= 60 && Number < 75)
            {
                Console.WriteLine("  Good");
            }
            else if (Number >= 75 && Number < 85)
            {
                Console.WriteLine(" Very Good");
            }
            else if (Number >= 85 && Number <= 100)
            {
                Console.WriteLine(" Excellent");
            }


            // nested if statment
            Console.WriteLine("Plaese Enter the first number : ");
            int first = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Plaese Enter the second number : ");
            int second = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Plaese Enter the third number : ");
            int third = Convert.ToInt32(Console.ReadLine());
            if (first > second)
            {
                if (first > third)
                {
                    Console.WriteLine("{0} is maximum Number", first);
                }
                else
                {
                    Console.WriteLine("{0} is maximum Number", third);
                }
            }
            else
            {
                if (second > third)
                {
                    Console.WriteLine("{0} is maximum Number", second);
                }
                else
                {
                    Console.WriteLine("{0} is maximum Number", third);
                }

            }
            /*
            char ch;
            Console.WriteLine("Enter an alphabet");
            ch = Convert.ToChar(Console.ReadLine());
            //switch
            switch (Char.ToLower(ch))
            {
                case 'a':
                    Console.WriteLine("Vowel alphabet");
                    break;
                case 'e':
                    Console.WriteLine("Vowel alphabet");
                    break;
                case 'i':
                    Console.WriteLine("Vowel alphabet");
                    break;
                case 'o':
                    Console.WriteLine("Vowel alphabet");
                    break;
                case 'u':
                    Console.WriteLine("Vowel alphabet");
                    break;
                default:
                    Console.WriteLine("  Not Vowel alphabet");
                    break;
            }
            */
            char ch;
            Console.WriteLine("Enter an alphabet");
            ch = Convert.ToChar(Console.ReadLine());
            //switch
            switch (Char.ToLower(ch))
            {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                    Console.WriteLine("Vowel alphabet");
                    break;


                default:
                    Console.WriteLine("  Not Vowel alphabet");
                    break;


            }

            //for loop
            for (int index1 = 0; index1 < 3; index1++)
            {

                Console.WriteLine("Welcome to C#");
            }

            // nested for loop
            for (int index2 = 1; index2 < 4; index2++)
            {

                for (int j = 1; j < 4; j++)
                {
                    Console.WriteLine(index2 + "  " + j);
                }
            }

            //while loop
            int i = 0;
            while (i < 10)
            {
                Console.WriteLine(i);
                i++;
            }

            //nested while loop
            int index3 = 1;
            while (index3 < 4)
            {
                int j = 1;
                while (j < 4)
                {
                    Console.WriteLine(i + "   " + j);
                    j++;

                }
                index3++;
            }

            //do while 
            int index4 = 1;
            do
            {
                int j = 1;
                do
                {
                    Console.WriteLine(index4 + "   " + j);
                    j++;
                } while (j < 4);

                index4++;
            } while (index4 < 4);


            //break
            for (int index5 = 1; index5 <= 5; index5++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    if (index5 == 4 && j == 1)
                    {
                        break;
                    }
                    Console.WriteLine(i + "   " + j);
                }
            }

            //continue=>skip , jump


            for (int index6 = 1; index6 <= 5; index6++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    if (index6 == 4 && j == 1)
                    {
                        continue;
                    }
                    Console.WriteLine(index6 + "   " + j);
                }
            }

            //array:group of similar type, zero index
            //declare array
            int[] Numbers = new int[5];
            //intilaize array
            Numbers[0] = 12;
            Numbers[1] = 20;
            Numbers[2] = 15;
            Numbers[3] = 25;
            Numbers[4] = 30;

            //display
            for (int ii = 0; ii < Numbers.Length; ii++)
            {
                Console.WriteLine(Numbers[ii]);
            }

            //array:group of similar type, zero index
            //declare array
            int[] nums = new int[] { 12, 20, 15, 25, 30, 60, 80, 100 };
            //intilaize array
            //Numbers[0] = 12;
            //Numbers[1] = 20;
            //Numbers[2] = 15;
            //Numbers[3] = 25;
            //Numbers[4] = 30;


            //display
            for (int iii = 0; iii < Numbers.Length; iii++)
            {
                Console.WriteLine(nums[iii]);
            }

            var x = 12365.254f;
            var name = "sahar";
            var checkVV = true;
            //array:group of similar type, zero index
            //declare array
            string[] cars = { "BMW", "Ford", "Volvo", "Marcedice" };

            //display foreach
            foreach (var s in cars)
            {
                Console.WriteLine(s);
            }

            //array:group of similar type, zero index
            //declare array
            string[] car = { "BMW", "Ford", "Volvo", "Marcedice" };



            //length of array 
            Console.WriteLine("Array Of length :  " + car.Length);
            // array of dim
            Console.WriteLine("Dim of Array : " + car.Rank);
            Array.Sort(car);
            Array.Reverse(car);

            //display
            for (int i1 = 0; i1 < cars.Length; i1++)
            {
                Console.WriteLine(cars[i1]);
            }

            //Array two dim
            int[,] arr = new int[3, 3];
            arr[0, 1] = 50;
            arr[1, 2] = 100;
            arr[2, 0] = 150;

            //display
            for (int i2 = 0; i2 < 3; i2++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(arr[i2, j] + "    ");
                }
                Console.WriteLine();
            }

            Console.WriteLine("-----------------");
            Console.WriteLine("length: " + arr.Length);
            Console.WriteLine("Dim: " + arr.Rank);

            //jagged array
            int[][] arrs = new int[3][]{
                new int[]{10,15,17,20},
                new int[]{2,8,},
                new int[]{30,50,25,80,15,20,30,60}

            };
            //display
            for (int i3 = 0; i3 < arr.Length; i3++)
            {
                for (int j = 0; j < arrs[i3].Length; j++)
                {
                    Console.Write(arrs[i3][j] + "    ");
                }
                Console.WriteLine();
            }


            Console.ReadKey();
        }
    }
}
