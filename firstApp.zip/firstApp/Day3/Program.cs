﻿using System;

namespace Day3
{
    class Program
    {

        //create function
        //no return + no parameter+static fn
        public static void Display()
        {

            Console.WriteLine("welcome to function Definition");
        }

        //no return + no parameter+ non static fn
        public void Display1()
        {

            Console.WriteLine("welcome to function Definition");
        }

        //create function
        // no return + paramter+ static
        public static void Hello(string name)
        {
            Console.WriteLine("Hello : " + name);
        }
        // no return + paramter
        public void Hello1(string name)
        {
            Console.WriteLine("Hello : " + name);
        }


        //return + paramter
        public int Sum(int a, int b)
        {

            return a + b;
        }

        public string HelloName(string name)
        {
            return " Hello :  " + name;
        }

        public int sum(int a, int b)
        {
            return a + b;
        }

        /// <summary>
        /// sum function used to add of two integar number
        /// </summary>
        /// <param name="a">this is first number</param>
        /// <param name="b"> this is second number</param>
        /// <returns></returns>
        public int sumNumbers(int a, int b)
        {
            return a + b;
        }

        //call by value
        public void Display(int val)
        {
            val *= val;//val=val * val
            Console.WriteLine(" val inside function    " + val);
        }

        //call by Reference
        public void Display(ref int val)
        {
            val *= val;//val=val * val
            Console.WriteLine(" val inside function    " + val);
        }

        public int DivisionFn(int a, int b)
        {
            return a / b;
        }
        public enum Departments
        {
            IT,
            HR,
            Sales,
            Operation
        }
        public enum Days
        {
            saturday,
            sunday,
            monday,
            tuesday,
            wenthday,
            thrusday,
            friday,
            sahar
        }

        public struct Employee
        {
            public int ID;
            public string Name;
            public decimal Salary;
            public void Show()
            {
                Console.WriteLine("ID : {0}   Name:   {1}  Salary: {2}$", ID, Name, Salary);
            }
        }

        // **************** Main ***********************
        static void Main(string[] args)
        {
            //create object
            Program p = new Program();
            //call fn
            Display();
            p.Display1();


            //create object
            Program p1 = new Program();
            //call fn
            Hello("sahar");
            p1.Hello1("Ahmed");

            //create object
            Program p2 = new Program();
            int z = p2.Sum(3, 10);
            Console.WriteLine(" z=" + z);
            Console.WriteLine("sum = " + p2.Sum(3, 10));

            //create object
            Program p3 = new Program();
            Console.WriteLine(p3.HelloName("Mohamed"));

            Console.WriteLine("please Enter First Number:");
            int FN = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("please Enter Second Number:");
            int SN = Convert.ToInt32(Console.ReadLine());


            //create object
            Program p4 = new Program();
            int Result = p4.sum(FN, SN);
            Console.WriteLine("Result = " + Result);

            Console.WriteLine("please Enter First Number:");
            int FN1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("please Enter Second Number:");
            int SN1 = Convert.ToInt32(Console.ReadLine());


            //create object
            Program p5 = new Program();
            int Result1 = p5.sumNumbers(FN1, SN1);
            Console.WriteLine("Result = " + Result1);


            int val = 50;
            Program p6 = new Program();
            Console.WriteLine("val before call fn   " + val);
            p6.Display(val);
            Console.WriteLine("val after call fn     " + val);

            int val1 = 50;
            Program p7 = new Program();
            Console.WriteLine("val before call fn   " + val1);
            p7.Display(ref val1);
            Console.WriteLine("val after call fn     " + val1);

            try
            {
                Console.WriteLine("Please Enter first Number : ");
                int FN2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Please Enter second Number : ");
                int SN2 = Convert.ToInt32(Console.ReadLine());
                //create object
                Program p8 = new Program();
                int Result2 = p8.DivisionFn(FN2, SN2);
                Console.WriteLine("Result = " + Result2);
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("please do not Enter zero in second number");
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("welcome from finally block");
            }


            //nullable type
            int? x = null;
            Console.WriteLine(x);

            //declare variable of enum
            Departments d;
            d = Departments.HR;
            Console.WriteLine(d);

            Console.WriteLine(Days.friday);


            Employee E = new Employee();
            E.ID = 101;
            E.Name = "Mohamed";
            E.Salary = 2000;
            E.Show();


            //stop console screen
            Console.ReadKey();

        }
    }
}
