﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Day5
{

    public interface Employee
    {
        void show();
        string Hello(string name);

    }
    public interface Demo
    {
        int sum(int a, int b);
    }
    public interface sample
    {

    }

    public class Manager : Employee, Demo, sample
    {
        public string Hello(string name)
        {
            return "Hello :   " + name;
        }

        public void show()
        {
            Console.WriteLine("welcome from show function");
        }

        public int sum(int a, int b)
        {
            return a + b;
        }
    }


    class Program
    {

        //Generic function
        public void Hello<T>(T msg)
        {
            Console.WriteLine(msg);
        }

        static void Main(string[] args)
        {
            Manager m = new Manager();
            m.show();
            Console.WriteLine(m.Hello("Mohamed"));

            Console.WriteLine(m.sum(20, 15));


            //collections
            //list create list of string
            var Names = new SortedSet<string>() { "Ahmed", "Mohamed", "Ali", "Khaled", "Mohamed" };
            //Names.Add("Ahmed");
            //Names.Add("Mohamed");
            //Names.Add("Ali");
            //Names.Add("Khaled");
            //Names.Add("Mohamed");
            //display
            foreach (var i in Names)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("----------------");
            var Numbers = new SortedSet<int>();
            Numbers.Add(12);
            Numbers.Add(17);
            Numbers.Add(15);
            Numbers.Add(11);
            Numbers.Add(12);
            Numbers.Add(18);
            //display
            foreach (var n in Numbers)
            {
                Console.WriteLine(n);
            }

            //collections
            //list create list of string
            var Names1 = new SortedSet<string>() { "Ahmed", "Mohamed", "Ali", "Khaled", "Mohamed" };
            //Names.Add("Ahmed");
            //Names.Add("Mohamed");
            //Names.Add("Ali");
            //Names.Add("Khaled");
            //Names.Add("Mohamed");
            //display
            foreach (var i in Names1)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("----------------");
            var Numbers1 = new SortedSet<int>();
            Numbers.Add(12);
            Numbers.Add(17);
            Numbers.Add(15);
            Numbers.Add(11);
            Numbers.Add(12);
            Numbers.Add(18);
            //display
            foreach (var n in Numbers1)
            {
                Console.WriteLine(n);
            }


            Stack<string> Names2 = new Stack<string>();
            Names2.Push("sahar");
            Names2.Push("amira");
            Names2.Push("mohamed");
            Names2.Push("omar");
            Names2.Push("ali");
            foreach (var name in Names2)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("-------------------------");
            Console.WriteLine("peek element:  " + Names2.Peek());
            Console.WriteLine("pop : " + Names2.Pop());
            Console.WriteLine("peek element:  " + Names2.Peek());

            Queue<string> Names3 = new Queue<string>();
            Names3.Enqueue("sahar");
            Names3.Enqueue("amira");
            Names3.Enqueue("mohamed");
            Names3.Enqueue("omar");
            Names3.Enqueue("ali");
            foreach (var name in Names3)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("-------------------------");
            Console.WriteLine("peek element:  " + Names3.Peek());
            Console.WriteLine("pop : " + Names3.Dequeue());
            Console.WriteLine("peek element:  " + Names3.Peek());

            //Generic

            Program p = new Program();
            p.Hello("Mohamed");
            p.Hello(500);
            p.Hello('S');
            p.Hello(true);
            Console.ReadKey();
        }
    }
}


/*
 * Create Unit testing
 * namespace Demotest.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void sumTest()
        {
            //intailize
            Program p = new Program();
            int x = 10;
            int y = 30;
            int expect = 40;
            int actual = 0;
            //act
            actual = p.sum(x, y);
            //assert
            Assert.AreEqual(expect, actual);
        }
    }
}
*/