﻿using System;

namespace firstApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to C# Intro!");

            //Comment inLine && multiLine

            /*Comment multiLine
             * 
             * 
             * */

            //how to declare variable
            //declare
            int x;
            //assign 
            x = 30;

            Console.WriteLine(x);

            string Name = "Sahar";
            bool myBool = true;


            Console.WriteLine(Name);
            Console.WriteLine(myBool);
            Console.Write("Hello");

            Console.Write(Name);
            Console.Write(myBool);
            Console.Write("Hello");

            char myChar = 's';
            Console.WriteLine(myChar);
            // user input

            const float Pi = 3.14f;
            //Pi = 5.7f;
            Console.WriteLine(Pi);

            int num = 5, y = 50, z = 100, m = 70;
            float f, h, o;

            Console.WriteLine("Enter your name : ");
            String Usrname = Console.ReadLine();
            Console.WriteLine("Welcome " + Usrname);

            string FullName = "Sahar Nasr";
            int Age = 29;
            float Salary = 3000;
            string Country = "Egypt";

            //concatenation
            Console.WriteLine("My name : " + FullName + "  " + "Age :  " + Age + "Years old "
                + "  " + "Salary: " + Salary + " $" + "  " + "Country: " + Country);

            //placeholder
            Console.WriteLine("My name: {0}  Age: {1}  years old Salary: {2}$  Country:{3}", FullName, Age, Salary, Country);


            //operators
            int xnum1 = 100 + 70;
            Console.WriteLine("x= " + x);


            int ynum2 = 121, mnum3 = 60;
            int n = y - m;
            int p = y * m;
            int d = y / m;
            Console.WriteLine("n = {0 }", n);
            Console.WriteLine("p = {0 }", p);
            Console.WriteLine("d = {0 }", d);
            // modularity
            int mo = ynum2 % mnum3;
            Console.WriteLine("mo = {0 }", mo);

            //operators
            int x1 = 10;
            int y1= 50;
            Console.WriteLine(x1 == y1);

            Console.WriteLine(x1 != y1);
            Console.WriteLine(x1 > y1);
            Console.WriteLine(x1 >= y1);

            Console.WriteLine(x1 > 5 && x1 < 9);
            Console.WriteLine(x1 > 5 || x1 < 9);
            int z1 = 100;
            z1 *= 30;//z=z*30;
            Console.WriteLine("z = " + z1);

            //implicit cast
            int i = 10;
            decimal d1 = i;
            Console.WriteLine("d =" + d1);

            //explicit cast
            double dd = 10.985;
            int ii = (int)dd;
            Console.WriteLine("ii=" + ii);
            string x2 = "62";
            int m1 = int.Parse(x2);
            Console.WriteLine(m1);

            //user input
            Console.Write("Please Enter Your Name :  ");
            string UsrName = Console.ReadLine();
            Console.Write("Please Enter Your Age :  ");
            int UsrAge = Convert.ToInt32(Console.ReadLine());
            Console.Write("Please Enter Your Salary :  ");
            decimal UsrSalary = Convert.ToDecimal(Console.ReadLine());


            Console.WriteLine("Welcome : {0} and your Age : {1} years old " +
                "and your salary : {2} $", UsrName, UsrAge, UsrSalary
                );

            //math class
            int z2 = Math.Min(18, 25);
            Console.WriteLine("z= " + z2);

            int m2 = Math.Max(18, 25);
            Console.WriteLine("m= " + m2);

            Console.WriteLine(Math.Max(100, 50));
            Console.WriteLine(Math.Abs(-60));
            Console.WriteLine(Math.Sqrt(64));
            Console.WriteLine(Math.Pow(8, 2));
            Console.WriteLine(Math.Floor(15.2));
            Console.WriteLine(Math.Ceiling(15.2));

            string nume = "Ahmed";
            Console.WriteLine(nume.ToUpper());
            Console.WriteLine(nume.ToLower());
            Console.WriteLine(nume.Length);

            //stop console screen
            Console.ReadKey();
        }
    }
}
